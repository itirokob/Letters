//
//  CorrectLetter.swift
//  Letter
//
//  Created by Bianca Itiroko on 19/07/18.
//  Copyright © 2018 Bianca Itiroko. All rights reserved.
//

import UIKit

class CorrectLetter: UIView {

    @IBOutlet weak var letter: UILabel!

}
